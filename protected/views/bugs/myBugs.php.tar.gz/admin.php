<?php
/* @var $this BugsController */
/* @var $model Bugs */

$this->breadcrumbs=array(
	'Bugs'=>array('index'),
	'Manage',
);

$this->menu=array(
	array('label'=>'List Bugs', 'url'=>array('index')),
	array('label'=>'Create Bugs', 'url'=>array('create')),
	array('label'=>'Мои баги', 'url'=>array('myBugs')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#bugs-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>Manage Bugs</h1>


<?php
	$currentAction = Yii::app()->controller->getAction()->getId();
	$this->widget('zii.widgets.CListView', array(
    'dataProvider'=>$model->search($currentAction),
    'ajaxUpdate'=>false,
    'template'=>'{pager}{summary}{items}{pager}',
    'itemView'=>'_view',
    'pager'=>array(
        'maxButtonCount'=>'7',
    ),
));
?>