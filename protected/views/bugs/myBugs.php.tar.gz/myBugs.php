<?php
/* @var $this BugsController */
/* @var $model Bugs */

$this->breadcrumbs=array(
	'Bugs'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List Bugs', 'url'=>array('index')),
	array('label'=>'Manage Bugs', 'url'=>array('admin')),
);

Yii::app()->clientScript->registerScript('search', "
$('.search-button').click(function(){
	$('.search-form').toggle();
	return false;
});
$('.search-form form').submit(function(){
	$('#bugs-grid').yiiGridView('update', {
		data: $(this).serialize()
	});
	return false;
});
");
?>

<h1>My bugs</h1>


<?php /*
	$currentAction = Yii::app()->controller->getAction()->getId();
	$this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'bugs-grid',
	'dataProvider'=>$model->search($currentAction),
	'filter'=>$model,
	'columns'=>array(
		'id',
		array(
			'name' => 'id_client',
			'type'=> 'raw',
			'value'=>'$data->ClientFio',
		),
		'address',
		'receive_date',
		'post',
		'start_date',
		'complete_date',
		 array(
			'name' => 'status',
			'type' => 'raw',
			'value' => '$data->getStatus($data->status)',
			'filter' => array(''=>'Все', 0=>'Ожидание', 1=>'В процессе', 2=>'Завершено'),
			  ),
		
		array(
			  'class'=>'CButtonColumn',
			'template'=>'{complete}{email}',
			 'buttons'=>array
			    (
			        'complete' => array
			        (
			            'label'=>'Завершить работу с багом',
			            'imageUrl'=>Yii::app()->request->baseUrl.'/images/accept.png',
			             'visible'=>'$data->status == 1',
			            'url'=>'Yii::app()->createUrl("bugs/completeBug", array("id"=>$data->id))',
			        ),

			         'email' => array
			        (
			            'label'=>'Отправить e-mail',
			            'imageUrl'=>Yii::app()->request->baseUrl.'/images/email.png',
			             'visible'=>'$data->status == 2',
			             'url'=>'Yii::app()->createUrl("bugs/sendMail", array("id"=>$data->id,))',			        
						),
			        ),
			    ),
		),
	),
));*/ ?>

<?php
	$this->widget('zii.widgets.CListView', array(
    'dataProvider'=>$dataProvider,
    'ajaxUpdate'=>false,
    'template'=>'{pager}{summary}{items}{pager}',
    'itemView'=>'_view',
    'pager'=>array(
        'maxButtonCount'=>'7',
    ),
));
?>